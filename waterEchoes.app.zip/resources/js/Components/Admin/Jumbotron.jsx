const Jumbotron = () => {
    return (
        <>
            <div className='tron'>
            </div>
        </>
    )
}

export default Jumbotron