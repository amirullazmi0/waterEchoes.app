
import { io } from "socket.io-client";
// const socket = io('https://skripsi-iot-ku.site/webSocket');

// console.log('socket', socket)

const Graph = () => {
    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 justify-center all-sensor">
                <div className="flex justify-center card bg-base-100 border shadow-sm p-2 m-2">

                    <div className="label-sensor">PH</div>
                </div>
            </div>
        </>
    )
}

export default Graph